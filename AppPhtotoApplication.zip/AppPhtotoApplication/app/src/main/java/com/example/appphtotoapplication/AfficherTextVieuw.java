package com.example.appphtotoapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class AfficherTextVieuw extends AppCompatActivity {
    private TextView txtV;
    private Button btn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_afficher_text_vieuw);

        txtV = (TextView)findViewById(R.id.txt_change);
        btn = (Button)findViewById(R.id.btn_change);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtV.setText("Bonjour Monsieur");
            }
        });
        btn.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                TextView text1 = findViewById(R.id.txt_change);
                text1.setText("Nous espèrons que vous allez bien");
                return true;
            }
        });

    }
}